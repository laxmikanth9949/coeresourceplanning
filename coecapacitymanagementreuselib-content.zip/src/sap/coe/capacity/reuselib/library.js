/*!
 * ${copyright}
 */
sap.ui.define(["jquery.sap.global","sap/ui/core/library"],function(jQuery){"use strict";sap.ui.getCore().initLibrary({name:"sap.coe.capacity.reuselib",version:"0.0.1",dependencies:["sap.ui.core","sap.m"],noLibraryCSS:true,types:[],interfaces:[],controls:["sap.coe.capacity.reuselib.controls.Example"],elements:[]});return sap.coe.capacity.reuselib},false);
//# sourceMappingURL=library.js.map