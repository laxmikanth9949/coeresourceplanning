sap.ui.define(["sap/coe/capacity/reuselib/utils/baseclasses/Helpers"],function(e){"use strict";var s=e.extend("sap.coe.rpa.util.Helpers",{});return new s});
//# sourceMappingURL=helpers.js.map