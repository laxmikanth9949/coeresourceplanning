sap.ui.define(["sap/coe/capacity/reuselib/utils/baseclasses/Helpers"],function(e){"use strict";return new e});
//# sourceMappingURL=helpers.js.map